import os
import sys
import spotipy
import spotipy.util as util
import requests
import urllib.parse

from flask import redirect, render_template, request, session
from functools import wraps


def apology(message, code=400):
    """Render message as an apology to user."""
    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [("-", "--"), (" ", "-"), ("_", "__"), ("?", "~q"),
                         ("%", "~p"), ("#", "~h"), ("/", "~s"), ("\"", "''")]:
            s = s.replace(old, new)
        return s
    return render_template("apology.html", top=code, bottom=escape(message)), code


def login_required(f):
    """
    Decorate routes to require login.

    http://flask.pocoo.org/docs/1.0/patterns/viewdecorators/
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated_function


# https://spotipy.readthedocs.io/en/latest/ reference
def authorize():
    try:
        token = util.prompt_for_user_token(
            '3qt8n4qgnmlqg5drog59e0igz',
            scope='playlist-modify-public user-library-read',
            client_id='d759d9996f5a4a589a70d14540c297f3',
            client_secret='d88a002bd112440a967a579d8d99675d',
            redirect_uri='http://ide50-dgmeaney.c9users.io:8080/login')
    except (AttributeError, JSONDecodeError):
        os.remove(f".cache-{username}")
        token = util.prompt_for_user_token(
            '3qt8n4qgnmlqg5drog59e0igz',
            scope='playlist-modify-public user-library-read',
            client_id='d759d9996f5a4a589a70d14540c297f3',
            client_secret='d88a002bd112440a967a579d8d99675d',
            redirect_uri='http://ide50-dgmeaney.c9users.io:8080/login')
    return token

