import os
import sys
import spotipy
import spotipy.util as util
import time

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, authorize

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
# https://spotipy.readthedocs.io/en/latest/ used as reference


@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Custom filter
app.jinja_env.add_extension('jinja2.ext.do')

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)


# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///final.db")


@app.route("/")
@login_required
def main():
    """Brings us to the main page"""
    return render_template("main.html")


@app.route("/check", methods=["GET"])
def check():
    """Return true if username available, else false, in JSON format"""
    # Get the username from the template
    username = request.args.get("username")

    # Check if username exists already
    results = db.execute("SELECT * FROM users WHERE username = :username", username=username)

    # If it does, return flase, else return true
    if results and len(username) >= 1:
        return jsonify(False)

    else:
        return jsonify(True)


@app.route("/check_playlist", methods=["GET"])
def check_playlist():
    """Return true if playlist_id is available, else false, in JSON format"""
    # Get the playlist_id from the template
    playlist_id = request.args.get("playlist_id")

    # Check if playlist_id exists already
    results = db.execute("SELECT * FROM playlist_list WHERE playlist_id = :playlist_id", playlist_id=playlist_id)

    # If it does, return flase, else return true
    if results:
        return jsonify(False)

    else:
        return jsonify(True)


@app.route("/check_double", methods=["GET"])
def check_double():
    """Return true if the song isnt already in the playlist, else false, in JSON format"""
    # Get the song information from the template
    song = request.args.get("song")
    song = ''.join(song)
    song = song.split(',')

    # Check if song exists already within this playlist
    current_session = db.execute("SELECT current_session FROM users WHERE id=:id", id=session["user_id"])
    results = db.execute("SELECT * FROM playlist WHERE name=:name AND artist=:artist AND song_id=:song_id AND playlist_id=:playlist_id",
                         name=song[0], artist=song[1], song_id=song[2], playlist_id=current_session[0]["current_session"])

    # If it does, return flase, else return true
    if results:
        return jsonify(False)

    else:
        return jsonify(True)


@app.route("/check_songs", methods=["GET"])
def check_songs():
    """Return true if the user can add another song, else false, in JSON format"""
    # Get the playlist id from the template
    playlist_id = request.args.get("playlist_id")

    # Get information on the amount of songs allowed to add and the number the user already has
    playlist_info = db.execute("SELECT * FROM playlist_list WHERE  playlist_id= :playlist_id", playlist_id=playlist_id)
    songs_added = db.execute("SELECT * FROM playlist WHERE  playlist_id= :playlist_id AND adder_id= :adder_id",
                             playlist_id=playlist_id, adder_id=session["user_id"])

    # If the user isnt the creator, and has exceded the number, return flase, else return true
    if len(songs_added) >= playlist_info[0]["number"] and playlist_info[0]["creator_id"] != session["user_id"]:
        return jsonify(False)

    else:
        return jsonify(True)


@app.route("/checkerplus", methods=["GET"])
def checkerplus():
    """Return true if the person can upvote a song, else false, in JSON format"""
    # Get the song name and id from the template
    name = request.args.get("name")
    song_id = request.args.get("song_id")
    # Check if the user has already upvoted the song, in this specific playlist
    user_info = db.execute("SELECT current_session FROM users WHERE id=:id", id=session["user_id"])
    results = db.execute("SELECT magnitude FROM votes WHERE name = :name AND id = :id AND song_id=:song_id AND playlist_id=:playlist_id",
                         name=name, id=session["user_id"], song_id=song_id, playlist_id=user_info[0]["current_session"])

    # If they have, return flase, else return true
    if results:
        if results[0]["magnitude"] >= 1:
            return jsonify(False)
        else:
            return jsonify(True)
    else:
        return jsonify(True)


@app.route("/checkerminus", methods=["GET"])
def checkerminus():
    """Return true if the person can downvote a song, else false, in JSON format"""
    # Get the song name and id from the template
    name = request.args.get("name")
    song_id = request.args.get("song_id")
    # Check if the user has already downvoted this song in this playlsit
    user_info = db.execute("SELECT current_session FROM users WHERE id=:id", id=session["user_id"])
    results = db.execute("SELECT magnitude FROM votes WHERE name = :name AND id = :id AND song_id=:song_id AND playlist_id=:playlist_id",
                         name=name, id=session["user_id"], song_id=song_id, playlist_id=user_info[0]["current_session"])

    # If they have, return flase, else return true
    if results:
        if results[0]["magnitude"] <= -1:
            return jsonify(False)
        else:
            return jsonify(True)
    else:
        return jsonify(True)


@app.route("/increase", methods=["GET"])
def increase():
    """updates the database so that a upvote from neutral is recorded"""
    # Get the song name, id and user information from the template
    name = request.args.get("name")
    song_id = request.args.get("song_id")
    user_info = db.execute("SELECT current_session FROM users WHERE id=:id", id=session["user_id"])

    # Check if the user has already voted and update the database if they have
    if db.execute("SELECT * FROM votes WHERE name = :name AND song_id=:song_id AND id = :id AND playlist_id=:playlist_id",
                  name=name, id=session["user_id"], song_id=song_id, playlist_id=user_info[0]["current_session"]):
        db.execute("UPDATE playlist SET votes = votes + 1 WHERE name = :name AND song_id=:song_id AND playlist_id=:playlist_id",
                   name=name, song_id=song_id, playlist_id=user_info[0]["current_session"])
        db.execute("UPDATE votes SET magnitude = magnitude + 1 WHERE name = :name AND song_id=:song_id AND id = :id AND playlist_id=:playlist_id",
                   name=name, id=session["user_id"], song_id=song_id, playlist_id=user_info[0]["current_session"])
        return jsonify(True)
    # Create a new row for the vote in the sql database, and update the amount of votes
    else:
        db.execute("UPDATE playlist SET votes = votes + 1 WHERE name = :name AND song_id=:song_id AND playlist_id=:playlist_id",
                   name=name, song_id=song_id, playlist_id=user_info[0]["current_session"])
        db.execute("INSERT INTO votes (id, name, magnitude, song_id, playlist_id) VALUES(:id, :name, :magnitude, :song_id, :playlist_id)",
                   id=session["user_id"], name=name, magnitude=1, song_id=song_id, playlist_id=user_info[0]["current_session"])
        return jsonify(True)


@app.route("/increase2", methods=["GET"])
def increase2():
    """updates the database so that a upvote from downvote is recorded"""
    # Get the song name, id and user information from the template
    name = request.args.get("name")
    song_id = request.args.get("song_id")
    user_info = db.execute("SELECT current_session FROM users WHERE id=:id", id=session["user_id"])

    # update the database
    db.execute("UPDATE playlist SET votes = votes + 2 WHERE name = :name AND song_id=:song_id AND playlist_id=:playlist_id",
               name=name, song_id=song_id, playlist_id=user_info[0]["current_session"])
    db.execute("UPDATE votes SET magnitude = magnitude + 2 WHERE name = :name AND song_id=:song_id AND id = :id AND playlist_id=:playlist_id",
               name=name, song_id=song_id, id=session["user_id"], playlist_id=user_info[0]["current_session"])
    return jsonify(True)


@app.route("/decrease", methods=["GET"])
def decrease():
    """updates the database so that a downvote from neutral is recorded"""
    # Get the song name, id and user information from the template
    name = request.args.get("name")
    song_id = request.args.get("song_id")
    user_info = db.execute("SELECT current_session FROM users WHERE id=:id", id=session["user_id"])

    # Check if the user has already voted and update that information if they have
    if db.execute("SELECT * FROM votes WHERE name = :name AND song_id=:song_id AND id = :id AND playlist_id=:playlist_id",
                  name=name, id=session["user_id"], song_id=song_id, playlist_id=user_info[0]["current_session"]):
        db.execute("UPDATE playlist SET votes = votes - 1 WHERE name = :name AND song_id=:song_id AND playlist_id=:playlist_id",
                   name=name, song_id=song_id, playlist_id=user_info[0]["current_session"])
        db.execute("UPDATE votes SET magnitude = magnitude - 1 WHERE name = :name AND song_id=:song_id AND id = :id AND playlist_id=:playlist_id",
                   name=name, id=session["user_id"], song_id=song_id, playlist_id=user_info[0]["current_session"])
        return jsonify(True)
    # create a new row for the vote in the sql database, and update the amount of votes
    else:
        db.execute("UPDATE playlist SET votes = votes - 1 WHERE name = :name AND song_id=:song_id AND playlist_id=:playlist_id",
                   name=name, song_id=song_id, playlist_id=user_info[0]["current_session"])
        db.execute("INSERT INTO votes (id, name, magnitude, song_id, playlist_id) VALUES(:id, :name, :magnitude, :song_id, :playlist_id)",
                   id=session["user_id"], name=name, magnitude=-1, song_id=song_id, playlist_id=user_info[0]["current_session"])
        return jsonify(True)


@app.route("/decrease2", methods=["GET"])
def decrease2():
    """updates the database so that a downvote from an upvote is recorded"""
    # Get the song name, id and user information from the template
    name = request.args.get("name")
    song_id = request.args.get("song_id")
    user_info = db.execute("SELECT current_session FROM users WHERE id=:id", id=session["user_id"])

    # update the database
    db.execute("UPDATE playlist SET votes = votes - 2 WHERE name = :name AND song_id=:song_id AND playlist_id=:playlist_id",
               name=name, song_id=song_id, playlist_id=user_info[0]["current_session"])
    db.execute("UPDATE votes SET magnitude = magnitude - 2 WHERE name = :name AND song_id=:song_id AND id = :id AND playlist_id=:playlist_id",
               name=name, song_id=song_id, id=session["user_id"], playlist_id=user_info[0]["current_session"])
    return jsonify(True)


@app.route("/create", methods=["GET", "POST"])
@login_required
def create():
    """Creates a new playlist"""
    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Get the name of the playlist and the number of songs they can add
        playlist_id = request.form.get("playlist_id")
        number = request.form.get("number")

        # Get authorization token
        token = authorize()

        # Create the Spotify playlist and check to make sure the number is a digit
        if number.isdigit() and token:
            sp = spotipy.Spotify(auth=token)
            results = sp.user_playlist_create('3qt8n4qgnmlqg5drog59e0igz', playlist_id, public=True)
            spotify_id = results['uri']
            link = results['owner']['external_urls']['spotify']

            # Update the database to include the link, playlist spotify id and number of songs allowed
            db.execute("INSERT INTO playlist_list (creator_id, playlist_id, number, spotify_id, link) VALUES(:creator_id, :playlist_id, :number, :spotify_id, :link)",
                       creator_id=session["user_id"], playlist_id=playlist_id, number=number, spotify_id=spotify_id, link=link)
            return redirect("/add")

        elif not token:
            return apology("no token", 403)

        else:
            # Return an apology if the number is bad
            return apology("must provide a number of songs", 403)

    else:
        # If the method is get, give them the template to create a playlist
        return render_template("create.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/vote_login", methods=["GET", "POST"])
@login_required
def vote_login():
    """vote login"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure playlist_id was submitted
        playlist_id = request.form.get("playlist_id")
        if not playlist_id:
            return apology("must provide playlist code", 403)

        # Query database for playlist_id
        rows = db.execute("SELECT playlist_id FROM playlist WHERE playlist_id = :playlist_id", playlist_id=playlist_id)

        # Ensure playlist_id exists
        if len(rows) < 1:
            return apology("playlist code incorrect", 403)
        # Set the users current session to reflect this playlist
        db.execute("UPDATE users SET current_session = :current_session WHERE id = :id",
                   current_session=(rows[0]["playlist_id"]),
                   id=session["user_id"])
        # Gather all information about the user, their voting, and the playlist itself
        user_info = db.execute("SELECT * FROM users WHERE id = :id", id=session["user_id"])
        rows = db.execute("SELECT * FROM playlist WHERE playlist_id = :playlist_id ORDER BY votes DESC",
                          playlist_id=user_info[0]["current_session"])
        votes = db.execute("SELECT * FROM votes WHERE id = :id AND playlist_id=:playlist_id",
                           id=session["user_id"], playlist_id=user_info[0]["current_session"])
        # Return the voting template, passing on this information
        return render_template("voting.html", rows=rows, user_info=user_info, votes=votes)

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("vote.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/playlist_login")


@app.route("/add", methods=["GET", "POST"])
@login_required
def add():
    """Add a song to the playlist"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Get the song title to search for
        search = request.form.get("songtitle")

        # Get playlist ID
        playlist_id = request.form.get("playlist_id")
        # If not a real id return apology
        if not playlist_id:
            return apology("must provide playlist code", 403)

        # Query database for playlist_id
        rows = db.execute("SELECT playlist_id FROM playlist_list WHERE playlist_id = :playlist_id", playlist_id=playlist_id)

        # Ensure playlist id exists
        if len(rows) < 1:
            return apology("playlist code incorrect", 403)

        # Update the users current session to this playlist
        db.execute("UPDATE users SET current_session = :current_session WHERE id = :id",
                   current_session=(rows[0]["playlist_id"]),
                   id=session["user_id"])

        # get authorization token
        token = authorize()

        # Create table for song information
        songs = [[0 for x in range(4)] for y in range(10)]
        count = 0

        # Search Spotify for the track
        if token:
            sp = spotipy.Spotify(auth=token)
            results = sp.search(search, limit=10, type='track')
            if not results:
                return apology("No results")
            else:
                for item in results['tracks']['items']:
                    artist = item['artists']
                    songs[count][0] = item['name']
                    songs[count][1] = artist[0]['name']
                    songs[count][2] = item['uri']
                    songs[count][3] = item['duration_ms']
                    count += 1
        else:
            return apology("Could not find token")

        # Pull user information to use in the confirm template
        user_info = db.execute("SELECT * FROM playlist_list WHERE playlist_id = :playlist_id", playlist_id=playlist_id)
        songs_added = db.execute("SELECT * FROM playlist WHERE  playlist_id= :playlist_id AND adder_id= :adder_id",
                                 playlist_id=playlist_id, adder_id=session["user_id"])
        x = user_info[0]["number"]-(len(songs_added) + 1)

        # Render the confirm template
        return render_template("confirm.html", songs=songs, user_info=user_info, x=x)

    else:

        # Return the add template if it was through get
        return render_template("add.html")


@app.route("/confirm", methods=["POST"])
def confirm():
    """Confirms the addition of a song"""
    # Get information about the song and split it into a manageable string
    song = request.form.get("song")
    song = ''.join(song)
    song = song.split(',')

    # Get information about the user
    current_session = db.execute("SELECT current_session FROM users WHERE id = :id", id=session["user_id"])
    creator_id = db.execute("SELECT creator_id FROM playlist_list WHERE playlist_id = :playlist_id",
                            playlist_id=current_session[0]["current_session"])
    # Insert this song into the playlist, with all relevant information
    db.execute("INSERT INTO playlist (playlist_id, creator_id, adder_id, name, artist, song_id, votes, length) VALUES(:playlist_id, :creator_id, :adder_id, :name, :artist, :song_id, :votes, :length)",
               playlist_id=current_session[0]["current_session"], creator_id=creator_id[0]["creator_id"],
               adder_id=session["user_id"], name=song[0], artist=song[1], song_id=song[2], length=song[3], votes=0)
    # Go back to the add page
    return redirect("/add")


@app.route("/playlist_login", methods=["GET", "POST"])
@login_required
def playlist_login():
    """Logs into the Playlist Screen"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure playlist ID was submitted
        playlist_id = request.form.get("playlist_id")
        if not playlist_id:
            return apology("must provide playlist code", 403)

        # Query database for Playlist ID
        rows = db.execute("SELECT playlist_id FROM playlist_list WHERE playlist_id = :playlist_id", playlist_id=playlist_id)

        # Ensure Playlist ID exists
        if len(rows) < 1:
            return apology("playlist code incorrect", 403)

        # Update the Users Current Session
        db.execute("UPDATE users SET current_session = :current_session WHERE id = :id",
                   current_session=(rows[0]["playlist_id"]),
                   id=session["user_id"])

        # Extract information from the databse to pass to playlist
        rows = db.execute("SELECT * FROM playlist WHERE playlist_id = :playlist_id ORDER BY votes DESC", playlist_id=playlist_id)
        link = db.execute("SELECT link FROM playlist_list WHERE playlist_id = :playlist_id", playlist_id=playlist_id)
        creator_id = db.execute("SELECT creator_id FROM playlist_list WHERE playlist_id = :playlist_id",
                                playlist_id=playlist_id)
        x = creator_id[0]["creator_id"]
        # Return the playlist template
        return render_template("playlist.html", rows=rows, x=x, link=link)

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        # Render the login template
        return render_template("playlist_login.html")


@app.route("/playlist", methods=["POST"])
def playlist():
    # Get information about the user
    user_info = db.execute("SELECT * FROM users WHERE id = :id", id=session["user_id"])

    # While there is are songs in the playlist queue keep adding songs
    while db.execute("SELECT * FROM playlist WHERE playlist_id = :playlist_id ORDER BY votes DESC",
                     playlist_id=user_info[0]["current_session"]):
        # Extract information about the playlist
        song_info = db.execute("SELECT * FROM playlist WHERE playlist_id = :playlist_id ORDER BY votes DESC",
                               playlist_id=user_info[0]["current_session"])
        playlist_info = db.execute("SELECT * FROM playlist_list WHERE playlist_id = :playlist_id",
                                   playlist_id=user_info[0]["current_session"])
        # get authorization token
        token = authorize()

        if token:
            # Define username from user_info and song_id from playlist_info
            song_id = [song_info[0]["song_id"]]
            playlist_id = playlist_info[0]["spotify_id"]
            print(song_id, playlist_id)
            sp = spotipy.Spotify(auth=token)

            # Add the song to the track
            sp.user_playlist_add_tracks('3qt8n4qgnmlqg5drog59e0igz', playlist_id, song_id, position=None)
        else:
            return apology("No token", 403)

        # Delete this song in this playlist from existence in databases
        db.execute("DELETE FROM playlist WHERE song_id=:song_id AND playlist_id=:playlist_id",
                   song_id=song_id, playlist_id=user_info[0]["current_session"])
        db.execute("DELETE FROM votes WHERE song_id=:song_id AND playlist_id=:playlist_id",
                   song_id=song_id, playlist_id=user_info[0]["current_session"])
        # Wait ten seconds
        time.sleep(10)
        length = song_info[0]["length"]

        # Wait length of song
        length = (int(length)/(1000))-10
        time.sleep(length)
    # return to playlist_login
    return redirect("/playlist_login")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 400)

        # Ensure password was submitted
        elif not request.form.get("password") or not request.form.get("confirmation"):
            return apology("must provide password", 400)

        # Ensure passwords match
        elif request.form.get("password") != request.form.get("confirmation"):
            return apology("passswords do not match", 400)

        hashed_password = generate_password_hash(request.form.get("password"), method='pbkdf2:sha256', salt_length=8)

        results = db.execute("INSERT INTO users (username, hash) VALUES(:username, :hash)",
                             username=request.form.get("username"),
                             hash=hashed_password)

        if not results:
            return apology("username already taken", 400)

        # Remember which user has logged in
        session["user_id"] = results
        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("register.html")


@app.route("/recs", methods=["GET", "POST"])
def recs():
    """ Give Reccomendations based on the top voted songs """

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure playlist ID was submitted
        playlist_id = request.form.get("playlist_id")
        if not playlist_id:
            return apology("must provide playlist code", 403)

        # Query database for Playlist ID
        rows = db.execute("SELECT playlist_id FROM playlist_list WHERE playlist_id = :playlist_id", playlist_id=playlist_id)

        # Ensure Playlist ID exists and password is correct
        if len(rows) < 1:
            return apology("playlist code incorrect", 403)

        # Get songs with votes > 1
        rows = db.execute(
            "SELECT * FROM playlist WHERE playlist_id = :playlist_id AND votes >= 1 ORDER BY votes DESC", playlist_id=playlist_id)

        # Make sure there are 5 or more upvoted songs
        if len(rows) < 5:
            return apology("You need 5 songs with more than 0 votes to recieve reccomendations", 403)
        else:
            tracks = [0 for x in range(5)]
            for x in range(5):
                tracks[x] = rows[x]['song_id']

        token = authorize()

        songs = [[0 for x in range(2)] for y in range(5)]
        count = 0

        # Search Spotify for recommendations
        if token:
            sp = spotipy.Spotify(auth=token)
            results = sp.recommendations(seed_artists=None, seed_genres=None, seed_tracks=tracks, limit=5, country=None)

            # Create a list of the top reccomended songs
            if not results:
                return apology("no results", 403)
            for item in results['tracks']:
                artist = item['artists']
                songs[count][0] = item['name']
                songs[count][1] = artist[0]['name']
                count += 1
        else:
            return apology("no token", 403)

        # Return the reccomendation template
        return render_template("recs.html", songs=songs)

    # User reached route via GET (as by clicking a link or via redirect)
    else:

        # Prompt the recoomendation form
        return render_template("recs_login.html")


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
