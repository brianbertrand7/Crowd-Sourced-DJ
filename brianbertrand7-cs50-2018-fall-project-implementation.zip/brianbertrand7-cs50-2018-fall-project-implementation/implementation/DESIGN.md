Welcome to our CS50 project! When designing our project we wanted a web-app that interacted with the Spotify API, in order to make
the application accessible for anyone on any device. To accomplish this we used the basic framework of CS50 Finance, and then
adapted/added/removed pages and functions to implement our crowd-sourced playlist. I will walk through the development of each
feature of our application, and explain the many design decisions we made both when coding in python, but also using
jinja, javascript and the Spotify API.

Interacting with the spotify API:
To interact with spotify, we used the documentation from Spotipy 2.0 (https://spotipy.readthedocs.io/en/latest/), which allows you
to perform actions such as search songs, create playlists, add songs to playlists, and get song recommendations. In order to utilize
efficient design, we placed the token authorization method within helpers.py, so that calling an authorization token for a pull
request from Spotify only takes one line within application.py. In addition, we kept the same authorization scope for all requests,
because a user could be on any page when their token expires and a refresh token is automatically pulled.

Our register and login methods are very similar to those we created in CS50 Finance, albeit slightly altered because we created a
different database and the login method redirects to a different location. We treated our homepage (/main) as in informational page,
providing tips on how to use the website to visitors. From that page, though, we created many different methods to implement all of
the features we desired.

Firstly, in the create method, we prompt the user for a playlist ID and number of song requests per person allowed. Before
submitting this form, we created javascript to check that the playlist ID has not already been taken, in order to avoid confusion
later when finding the playlist on Spotify. We also decided to create all playlists publicly under one Spotify account - Party
Playlist - such that each user did not have to authorize their Spotify account (although they will need Spotify to play music). Upon
form submission, we stored this in a table called playlist_list, such that each row contains the playlist ID, creator ID, link to
the playlist on Spotify, and number of songs allowed per user.

Once we created the playlist, we worked on the add method, such that users can search songs in Spotify to add them to a particular
palylist. Simiarly to create, we channeled all song requests through a singular Spotify account and search only by song title, to
make it easier for users to find the songs they are looking for without a long authorization process. After checking to make sure
that the playlist ID they entered is valid, we queried Spotify for songs, indexed the list of dictionaries of lists that the query
returned, and then rendered a confirmation template. We decided to include a confirmation template so that we could return multiple
song results in case the wished for song was not the first one to be returned. To create this template, we created an array of 4x10,
including the name, artist, Spotify ID, and length of 10 songs, and then used Jinja to create a selection menu. Upon confirmation,
the song is added to the playlist table with all of the aformentioned information and a tag to the playlist ID.

Then, one of the major components of our site is the voting portion. This part was especially tricky to create as we had to
incorporate a lot of jinja logic, as well as javascript and ajax, to make sure that the voting platform would work properly.
First we begin with the logging in.Here we see that the songs are displayed, with name, artist and current vote state.  This was
done easily witha jinja for loop, but then the like and dislike column used conditionals to make sure that the user would see the
current status of their votes.  We made comparisons within the votes table, which contain all of the votes ever made, tied to a
song, user, playlist, and it also contains their magnitude. Next, each time an arrow is clicked we have javascript logic determine
which arrows ought to light up and which arrows ought to blacken.  This was done by making comparisons between the img src, whether
it was lit up or not, knowing that the condition of each of them, meant something about how the user had voted. So if it was going
from upvoting to neutral or vice versa, or downvoting to neutral or vice versa, we knew that we would only change votes by 1,
This was done by using ajax to call methods that updated the databases accordingly.  Similarly when we went from upvoting to
downvoting or vice versa, we knew that the change in magnitude of the vote was 2, so we had to call different methods.  We decided
that in the end, it was better to have the user be allowed to refresh the page whenever they choose, rather than refreshing after
each action, as it really slowed the flow. This allowed for a less clunky user interface.

The next step of our design was actually getting the playlist we had created in Spotify to have the right songs, at the right time,
in the right order. In order to accomplish this, we created a large while loop that encopassed a function that, in order, pulled
the song with the necessary playlist ID and the most votes from our database, checked if new Spotify authorization was needed,
inserted the song into the Spotify playlist via Spotipy, deleted the song just added to the playlist, and then set a countdown such
that when 10 seconds of the last played song remained, the loop would run again and a new song would be inserted. Because many of
the functions we wrote were contigent on having a valid playlist ID, we had to create many login pages for each of our functions,
that could then check whether a playlist ID is valid and then pass that ID to the intended function (ex. playlist_login.html is
the login page for the playlist method, and recs_login is the login page that validates entry to the recommendations page. In order
to get the playlist to play correctly in Spotify, we had to make sure that we stored all information correctly (such as the
unique song ID provided by Spotify and the length of the song (given in milliseconds)). By then providing a link (via html) to the
user, but onyl the creator of the playlist (checked via SQL), the person who created the playlist is the only one who can view it
and consequentially play it on Spotify.

The final method that we decided to implement in our project is the recommendations page. To implement this, we had to pull all
songs with more than 0 votes from the playlist table that were in a certain playlist. In order to make sure that recommendations
truly matched the most popular songs in the playlist, we set the minimum numbers of upvoted songs as 5 (which is also the maximum
that the spotify argument takes) and required that they all have a positive amount of votes (checked through SQl). after creating
a list of the top 5 song IDs, we checked to see if an auhtorization token was needed (and retrieved that if necessary), and then
used the spotipy recommendations argument. Those we then displayed on a separate table using jinja, and limited the amount displayed
to 5, once again to make sure that they were representative of the playlist, but also because the Spotify API was not performing
well and we wanted to make our code as efficient as possible.
