Link to the video
https://www.youtube.com/watch?v=WpNBnRrEmJ0
