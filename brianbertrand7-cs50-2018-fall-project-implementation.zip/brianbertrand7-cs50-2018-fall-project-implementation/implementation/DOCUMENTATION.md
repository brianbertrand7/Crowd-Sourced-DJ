This Tutorial will go over the best way to run this application.  First and foremost, This app requires you to have spotify open,
and a premium account in order to be used, as it uses the spotify api. Also, it works best when the device you are playing music
with is a phone. So now I will go in to the details of how to use this app as a playlist creator or as a voter at the venue the
creator is djing.


In order to open the project in the terminal, cd project, followed by cd implementation. The source code should be perfectly fine
and ready to be used with a simple “flask run” in the terminal, followed by clicking on the link.  However, just to make sure, make
sure that all of the tables in final.db are free of entries (don’t delete the actual tables, just clear them of entries), and then
run “flask run”. Next follow the directions below.

REGISTER
The first step is to register.  This is done by clicking the register button on the nav bar in the upper right corner labeled
register.  You must enter a unique username and any password you desire, and make sure that the password matches the password
confirmation. This will then log you in and redirect you to the homepage.

CREATE (creator- spotify ID required)
You can create a playlist by clicking create in the navbar.  You will be prompted to create the playlist id (the name that you will
tell everyone at your event to use as the playlist id code), and define the number of songs you want to allow everyone at the event
to add to playlist.  This creates the Playlist. If the playlist is already taken you will be prompted to create a new one.

ADD
You can add songs by going to the add tab on the navbar.   Depending on whether you created the playlist, or whether you are a
regular user simply voting on the playlist will determine how many songs you can add (unlimited if you are the creator, or the
amount defined by the creator if you are not the creator).  So now type in the name of the song and the playlist name, and submit
that form.  That will then lead you to a confirmation menu with a drop down menu of a couple of options for the song(10).  Select
which one you want and hit submit.

VOTE
To vote on the songs, go to the vote tab on the navbar.  Type in the playlist ID and hit submit.  That will bring you to a page
that has all of the songs, as well as their artists, in a table.  In addition, every song has a black up arrow and a black down
arrow.  You can click the up arrow to upvote a song, or you can click the black arrow to downvote the song.  To see the changes,
simply refresh the page and click the confirm form submission button on the alert.  This saves a lot of time so the table doesn’t
have to load again and again and again.  Also, you can change your vote as many times as you want, and the table will also display
the votes of other users on the same playlist.

RECOMMENDATION
This method is really simple.  Go to the recommendations tab on the nav bar and click on it.  Then submit the playlist ID into the
Playlist ID field, and hit submit.  This will load 5 song recommendations for you to be inspired by and maybe add to your playlist.
Note that this will only work if there are five songs in the playlist with more than 0 votes.

PLAYING (creator only - spotify ID required)
To play the playlist, go to the playlist tab on the navbar.  This will display the current order of the songs and you can hit start
to start the playlist.  Don’t worry, the order will change as voting continues and requires nothing on your end(if you are using a
phone, if you are using a computer, you will have to refresh after the end of each song, before the new one to update the playlist).
When you are ready to play, click the start button, and follow the instructions on screen.  Press and hold on the link and select
open in spotify if on a phone, or click the link and open in a new tab if on a computer.  From there you should be able to browse
through the playlists and once you see your own playlist that has the same title as your playlist ID click on it. The first song
will be there, hit play, and go back to your app to continue voting and adding songs! 10 seconds before the end of a song the next
song will be pulled from the database and added to the Spotify playlist, so do not worrry if you do not see the next song appear in
Spotify until the current one is nearly over.

SOME THINGS THAT OUR WEBSITE DOES NOT SUPPORT

You cannot search for songs by artist or album, if you do the search will go through but results will probably not be what you want.

Skipping tracks and stopping and starting the playlist are pretty much not available on our website. To pause I would reccomend just
turning the volume down. You can pause in the Spotify app if you want, but the playlist function will continue to run.

Due to limitations in the Spotify API, you cannot play music in Safari, you must use Chrome or Firefox.



