# Status Report

#### Your name

Daniel Meaney

#### Your section leader's name

Toby Satterthwaite

#### Project title

A Collaborative Party Playlist using the Spotify API

***

Short answers for the below questions suffice. If you want to alter your plan for your project (and obtain approval for the same), be sure to email your section leader directly!

#### What have you done for your project so far?

We have set up all of the HTML pages, as well as a lot of the python code that dynamically generates the website.

#### What have you not done for your project yet?

WE have yet to implement a bit of the python code for the website, in order to make sure it runs properly, as well as almost all of
java script.  In addition, we have not begun to implement the spotify API.

#### What problems, if any, have you encountered?

Delving into the Spotify API has definitely been difficult, as it is a bit more complicated than originally anticipated.

