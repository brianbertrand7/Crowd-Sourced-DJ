# Proposal

## What will (likely) be the title of your project?

Party Playlist

## In just a sentence or two, summarize your project. (E.g., "A website that lets you buy and sell stocks.")

Create a live playlist so people in a group can upvote/downvote songs to determine their order.

## In a paragraph or more, detail your project. What will your software do? What features will it have? How will it be executed?

The goal of our project is to create a website where, for a certain party, there will be one host who can share a unique code so
others can join the group. Those people will be able to add songs to the current playlist, along with beign able to upvote/downvote
other people's choices to create the order (i.e. the songs with the most upvotes play first and the songs with the least play last).

Other features:
-display current playlist order to each user
-view vote history
-view what happened to all of the songs they requested
-use Bootstrap to format the website so people can use it either on a phone or computer

Execution:
-we will store all of our data in SQL, such that it can be accessed by any user that needs to get to certain songs or playlist
    history
-the website will be python based and then we will use HTML and CSS to create and format templates
-the Spotify API documentation will allow us to work on including Spotify in our website

## If planning to combine CS50's final project with another course's final project, with which other course? And which aspect(s) of your proposed project would relate to CS50, and which aspect(s) would relate to the other course?

TODO, if applicable

## In the world of software, most everything takes longer to implement than you expect. And so it's not uncommon to accomplish less in a fixed amount of time than you hope.

### In a sentence (or list of features), define a GOOD outcome for your final project. I.e., what WILL you accomplish no matter what?

A list of songs that people can upvote or downvote to create the playlist order. In this case, the songs would be predetermined by
the party host (the person who set up the playlist).

### In a sentence (or list of features), define a BETTER outcome for your final project. I.e., what do you THINK you can accomplish before the final project's deadline?

Everything included in GOOD, plus the ability for other users to request songs and have them added to the playlist (a certain number
allowed per person by the host).

### In a sentence (or list of features), define a BEST outcome for your final project. I.e., what do you HOPE to accomplish before the final project's deadline?

Everything included in BETTER, plus Spotify then suggests more songs based on the songs that get upvoted and added, these songs
would then be subject to voting.

## In a paragraph or more, outline your next steps. What new skills will you need to acquire? What topics will you need to research? If working with one of two classmates, who will do what?

We will start by making the frame of the website (i.e. creating the pages we need with the right files/templates). After that,
we can work in implenenting one level of success at a time (GOOD, BETTER, BEST). We will need to do substantial research into the
Spotify API, at https://developer.spotify.com/documentation/web-api/. This is the main new skill we need to acquire, everything else
we think that we have prior experience with.

Since this is a group of two, we will need to fairly split up the work involved. One person (TBD) will work on creating the actual
website and implements most of the features there, while the other focuses on understanding how to get Spotify to interact with it.
Of course, both people will need to understand both areas, but by focusing on one the work may get done more quickly, efficiently,
and successfully.
