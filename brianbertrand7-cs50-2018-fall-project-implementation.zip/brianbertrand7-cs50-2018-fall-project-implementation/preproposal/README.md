# Preproposal

## What idea(s) do you have for your final project?

We plan on making some type of python based website and using Bootstrap to format it. Content wise, we are currently
thinking of creating a crowd-sourced playlist application using the Spotify API. There will be one account in charge of the
playlist, and other members can request or suggest songs, along with upvoting or downvoting them anonymously. We would like
to add other helpful features, and will decide those as we implement the program.

## If you plan to collaborate with one or two classmates, what are their names, and who are their section leaders?

Brian Bertrand - Section Leader: Krishna Suraj

## Do you have any questions of your own?

Are there any extra opportunities to receive using the API, besides the Hackathon?
Also, how many features should our website include for a satisfactory grade?
